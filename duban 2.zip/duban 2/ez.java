public class ez {
}
