package com.company;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
    Kalkulacka kalkulacka = new Kalkulacka();
    Scanner sc = new Scanner(System.in);

    System.out.println("Zadaj cislo a: ");
    kalkulacka.a = sc.nextInt();
    System.out.println("Zadaj cislo b: ");
    kalkulacka.b = sc.nextInt();

   kalkulacka.scitaj();
   int vysledok = kalkulacka.odcitaj();
   System.out.println(vysledok);

   System.out.println("Vynasob vysledok: " + kalkulacka.vynasob());

   System.out.println("Vydel vysledok: " + kalkulacka.vydel());



    }
}




