package com.company;

public class Zdravic {
    public String text;

    public  void pozdrav (){

        System.out.println("Ahoj svet");
    }
}